from iJal.app import create_app

app = create_app()