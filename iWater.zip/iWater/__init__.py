from iWater.app import create_app

app = create_app()

# @app.route('/')
# def hello_world():
#     return '<h1>Hello, World! I am iWater.</h1> \
#         Please go visit <a href="/">Core App</a><br><a href="/itraining">iTraining</a>'